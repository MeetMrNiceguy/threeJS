import * as THREE from 'three';

import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader'

import init from './init';

import './style.css';

const { sizes, camera, scene, canvas, controls, renderer } = init();

camera.position.set(0, 2, 5);

const floor = new THREE.Mesh(
	new THREE.PlaneGeometry(10, 10),
	new THREE.MeshBasicMaterial({
		color: 'white',
		metalness: 0,
		roughness: 0.5
	}),
);

floor.receiveShadow = true;
floor.rotation.x = -Math.PI * 0.5;
floor.position.y = -1;
scene.add(floor);

const hemiLight = new THREE.HemisphereLight(0xffffff, 0xffffff, 0.61);
hemiLight.position.set(0, 50, 0);
scene.add(hemiLight);

const dirLight = new THREE.DirectionalLight(0xffffff, 0.54);
dirLight.position.set(-8, 12, 8);
dirLight.castShadow = true;
dirLight.shadow.mapSize = new THREE.Vector2(1024, 1024);
scene.add(dirLight);

const loader = new GLTFLoader();

let currentModel = null;

function updateButtonsCount(currentScene) {
  const sceneChildren = currentScene.children;

  const buttonsContainer = document.getElementById('buttonsContainer');
  buttonsContainer.innerHTML = ''; // Remove all buttons from container

  // Add new buttons to container
  for (let i = 0; i < sceneChildren.length; i++) {
    const child = sceneChildren[i];
    const button = document.createElement('button');
    button.className = 'activebut';
    button.id = 'button' + i;
    button.textContent = 'Показать дополнительно: ' + child.name; // Add child's name to button text
    buttonsContainer.appendChild(button);
    button.addEventListener('click', buttonClick); // Add event listener to button
  }
}

function loadChildModel(event) {
  const button = event.target;
  const index = parseInt(button.id.replace('button', ''));
  const child = currentModel.children[index];
  const path = child.userData.path;
  loadModel(path);
}

function loadModel(path) {
  if (currentModel) {
    // Удалить текущий дочерний элемент из сцены
    scene.remove(currentModel);
    currentModel.traverse(function (object) {
      if (object.isMesh) object.geometry.dispose();
    });

    // Сбросить ссылку на текущий дочерний элемент
    currentModel = null;
  }

  loader.load(
    path,
    function (gltf) {
      const model = gltf.scene;

      if (model.children.length > 0) {
        // Добавить только новый дочерний элемент
        const child = gltf.scene.children[0].clone(); // Создать копию дочернего элемента
        scene.add(child);
        currentModel = child; // Сохранить ссылку на новый дочерний элемент
      }

      // Добавить путь к загруженной модели в дочерние элементы
      model.traverse(function (child) {
        if (child.isMesh) {
          child.userData.path = path;
        }
      });

      // Обновить список кнопок передавая модель в функцию
      updateButtonsCount(model);

      console.log("Модель успешно загружена");
    },
    function (xhr) {
      console.log((xhr.loaded / xhr.total) * 100 + "% загружено");
    },
    function (error) {
      console.log("Ошибка загрузки модели:", error);
    }
  );
}

// Обработчик события клика на кнопку
function buttonClick(event) {
  const button = event.target;
  const id = button.id;

  const models = {
    modelM: './models/Mka.glb',
    naves: './models/tester.gltf',
    stol: './models/modelM.glb'
  };

  if (models.hasOwnProperty(id)) {
    const path = models[id];
    loadModel(path);
  } else {
    console.log("Модель не найдена для данного id");
  }
}

const buttons = document.querySelectorAll('.activebut');
buttons.forEach(function (button) {
  button.addEventListener('click', buttonClick);
});

const tick = () => {
  controls.update();
  renderer.render(scene, camera);
  window.requestAnimationFrame(tick);
};
tick();

/* Базовые обпаботчики событий длы поддержки ресайза */
window.addEventListener('resize', () => {
  // Обновляем размеры
  sizes.width = window.innerWidth;
  sizes.height = window.innerHeight;

  // Обновляем соотношение сторон камеры
  camera.aspect = sizes.width / sizes.height;
  camera.updateProjectionMatrix();

  // Обновляем renderer
  renderer.setSize(sizes.width, sizes.height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.render(scene, camera);
});

canvas.addEventListener('dblclick', () => {
  if (!document.fullscreenElement) {
    canvas.requestFullscreen();
  } else {
    document.exitFullscreen();
  }
});